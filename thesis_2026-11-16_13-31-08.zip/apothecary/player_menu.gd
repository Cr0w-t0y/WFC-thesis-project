extends CanvasLayer

# Quick reference to our TabContainer and Buttons
@onready var menu_tabs: TabContainer = $JornualBackground/MenuTabs
@onready var main: Button = $HBoxContainer/main
@onready var inventory: Button = $HBoxContainer/inventory
@onready var relations: Button = $HBoxContainer/relations
@onready var herbs: Button = $HBoxContainer/herbs
@onready var recipes: Button = $HBoxContainer/recipes

func _ready() -> void:
	visible = false
	
	# Connect our custom buttons to switch the tabs
	main.pressed.connect(func(): switch_to_tab(0))
	inventory.pressed.connect(func(): switch_to_tab(1))
	relations.pressed.connect(func(): switch_to_tab(2))
	herbs.pressed.connect(func(): switch_to_tab(3))
	recipes.pressed.connect(func(): switch_to_tab(4))

# Changed from _input to _unhandled_input to play nice with UI focus
func _unhandled_input(event: InputEvent) -> void:
	# Toggle general menu with TAB
	if event.is_action_pressed("menu"):
		toggle_menu()
		
	# Specific direct shortcuts (only trigger if menu is closed, or switch tabs if open)
	elif event.is_action_pressed("inventory"):
		open_specific_tab(1)

func toggle_menu() -> void:
	visible = !visible
	get_tree().paused = visible # Pauses the world/movement while reading!
	
	if visible:
		# Default to the first tab when opened via TAB
		switch_to_tab(0)

func open_specific_tab(tab_index: int) -> void:
	if !visible:
		visible = true
		get_tree().paused = true
	switch_to_tab(tab_index)

func switch_to_tab(index: int) -> void:
	if index >= 0 and index < menu_tabs.get_child_count():
		menu_tabs.current_tab = index
		print("page flipped to tab: ", index)
