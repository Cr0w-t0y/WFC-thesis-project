extends CharacterBody2D


const SPEED = 300.0
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

var last_direction : Vector2 = Vector2.RIGHT

##-----------------------------------------
## Movement and animation
##-----------------------------------------

func _physics_process(_delta: float) -> void:
	process_movement()
	move_and_slide()
	process_animation(last_direction)

func process_movement() ->void:
	var direction := Input.get_vector("left","right","up","down") ##project settings -> input map
	
	if direction != Vector2.ZERO: ##player is moving
		velocity = direction * SPEED
		last_direction = direction
	else :                         ##player is not moving -> idle
		velocity = Vector2.ZERO
	
	velocity = direction * SPEED
	
	

func process_animation(direction) ->void:
	if velocity != Vector2.ZERO:
		play_animation("run", direction)
	else :
		play_animation("idle", direction)
		
		## add directional idle. code works and remembers where player was facing and calls that animation

func play_animation(prefix: String,dir: Vector2) ->void: ##string makes it versatile, so don't need to hard code animation names
	if dir.x > 0 :
		animated_sprite_2d.play(prefix + "_right")
	elif dir.y <0:
		animated_sprite_2d.play(prefix + "_up")
	elif dir.y > 0:
		animated_sprite_2d.play(prefix + "_down")
	elif dir.x < 0: 
		animated_sprite_2d.play(prefix + "_left")
		
		##even if sprites are swapped, don't gotta rename
