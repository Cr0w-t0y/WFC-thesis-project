extends Node2D

var level: int = 1
var current_level_root: Node = null


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	current_level_root = get_node("levelroot")
	_load_level(level)
	

func _load_level(level_number: int) -> void:
	if current_level_root:
		current_level_root.queue_free()
	var level_path = "res://scenes/levels/testmap.tscn" % level_number
	current_level_root = load(level_path).instantiate()
	add_child(current_level_root)
	current_level_root.name = "levelroot"
	_setup_level(current_level_root)

func _setup_level(level_root: Node) -> void:
	var exit = level_root.get_node_or_null("Exit")
	if exit:
		exit.body_entered.connect(on_exit_body_entered)


func on_exit_body_entered(body: Node2D) -> void:
	if body.name == "player":
		level += 1
		print(level) # making sure it actually loads
		call_deferred("_load_level",(level))

#it has an error when trying to load level 3. that is fine! it's cause it doesnt exist, but it could
#this will likely be modified when the WFC comes in
#idk how yet, I'll do research once the json library is done
