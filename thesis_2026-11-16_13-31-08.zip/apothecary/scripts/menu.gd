extends CanvasLayer
# Quick reference to the menu control node
@onready var inventory_menu: Control = $"menu_layout"

func _ready() -> void:
	# Make sure it starts hidden just in case
	inventory_menu.visible = false

func _unhandled_input(event: InputEvent) -> void:
	# Check if the player pressed the Tab action
	if event.is_action_pressed("menu"):
		toggle_menu()

func toggle_menu() -> void:
	# Flip the current visibility state
	inventory_menu.visible = !inventory_menu.visible
	
	# Optional: Manage mouse mode and game pause status based on menu state
	if inventory_menu.visible:
		print("Inventory opened! Ready for item programming.")
		# If you need the mouse cursor to appear in a 3D/captured game:
		# Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		print("Inventory closed.")
		# Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
